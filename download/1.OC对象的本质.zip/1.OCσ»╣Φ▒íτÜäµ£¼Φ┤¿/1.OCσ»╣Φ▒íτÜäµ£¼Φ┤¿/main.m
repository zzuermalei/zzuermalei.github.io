//
//  main.m
//  1.OC对象的本质
//
//  Created by iStones on 2018/8/19.
//  Copyright © 2018年 iStones. All rights reserved.
//
//  将 main.m 输出为 main.cpp
//  xcrun  -sdk  iphoneos  clang  -arch  arm64  -rewrite-objc main.m  -o main.cpp

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
