//
//  SerialQueueDemo.m
//  线程同步方案
//
//  Created by iStones on 2018/9/7.
//  Copyright © 2018年 iStones. All rights reserved.
//

#import "SerialQueueDemo.h"

@interface SerialQueueDemo ()
@property (nonatomic, strong) dispatch_queue_t moneyQueue;
@property (nonatomic, strong) dispatch_queue_t ticketQueue;
@end

@implementation SerialQueueDemo

#pragma mark - init
- (instancetype)init {
    if (self = [super init]) {
        self.moneyQueue = dispatch_queue_create("top.istones.moneyQueue", DISPATCH_QUEUE_SERIAL);
        self.ticketQueue = dispatch_queue_create("top.istones.ticketQueue", DISPATCH_QUEUE_SERIAL);;
    }
    return self;
}

#pragma mark - override
- (void)__saveMoney {
    dispatch_sync(self.moneyQueue, ^{
        [super __saveMoney];
    });
}

- (void)__drawMoney {
    dispatch_sync(self.moneyQueue, ^{
        [super __drawMoney];
    });
}

- (void)__saleTicket {
    dispatch_sync(self.moneyQueue, ^{
        [super __saleTicket];
    });
}

@end
