//
//  PthreadMutexCondDemo.m
//  线程同步方案
//
//  Created by iStones on 2018/9/6.
//  Copyright © 2018年 iStones. All rights reserved.
//

#import "PthreadMutexCondDemo.h"
#import <pthread.h>

@interface PthreadMutexCondDemo ()
@property (nonatomic, assign) pthread_mutex_t mutex;
@property (nonatomic, assign) pthread_cond_t cond;
@property (nonatomic, strong) NSMutableArray *array;
@end

@implementation PthreadMutexCondDemo

#pragma mark - init
- (instancetype)init {
    if (self = [super init]) {
        pthread_mutex_init(&_mutex, NULL);
        pthread_cond_init(&_cond, NULL);
    }
    return self;
}

#pragma mark - override
- (void)otherTest {
    [[[NSThread alloc] initWithTarget:self selector:@selector(__remove) object:nil] start];
    
    sleep(2);
    
    [[[NSThread alloc] initWithTarget:self selector:@selector(__add) object:nil] start];
}

#pragma mark - private methods
- (void)__add {
    NSLog(@"%s", __func__);
    
    pthread_mutex_lock(&_mutex);
    
    [self.array addObject:@"test"];
    NSLog(@"添加了元素");
    
    pthread_cond_signal(&_cond);
    
    pthread_mutex_unlock(&_mutex);
}

- (void)__remove {
    
    NSLog(@"%s", __func__);
    
    pthread_mutex_lock(&_mutex);
    
    if (self.array.count == 0) {
        // 等待
        pthread_cond_wait(&_cond, &_mutex);
    }
    
    [self.array removeLastObject];
    NSLog(@"删除了元素");
    
    pthread_mutex_unlock(&_mutex);
}

- (void)dealloc {
    pthread_mutex_destroy(&_mutex);
    pthread_cond_destroy(&_cond);
}

@end
