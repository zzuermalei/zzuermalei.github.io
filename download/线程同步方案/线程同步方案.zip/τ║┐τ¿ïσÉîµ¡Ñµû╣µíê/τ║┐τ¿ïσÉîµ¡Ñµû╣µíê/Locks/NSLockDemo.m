//
//  NSLockDemo.m
//  线程同步方案
//
//  Created by iStones on 2018/9/6.
//  Copyright © 2018年 iStones. All rights reserved.
//

#import "NSLockDemo.h"

@interface NSLockDemo ()
@property (nonatomic, strong) NSLock *moneyLock;
@property (nonatomic, strong) NSLock *ticketLock;
@end

@implementation NSLockDemo

#pragma mark - init
- (instancetype)init {
    if (self = [super init]) {
        self.moneyLock = [[NSLock alloc] init];
        self.ticketLock = [[NSLock alloc] init];
    }
    return self;
}

#pragma mark - override
- (void)__saveMoney {
    [self.moneyLock lock];
    
    [super __saveMoney];
    
    [self.moneyLock unlock];
}

- (void)__drawMoney {
    [self.moneyLock lock];
    
    [super __drawMoney];
    
    [self.moneyLock unlock];
}

- (void)__saleTicket {
    
    [self.ticketLock lock];
    
    [super __saleTicket];
    
    [self.ticketLock unlock];
}

@end
