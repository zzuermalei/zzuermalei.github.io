//
//  OSUnfairLockDemo.m
//  线程同步方案
//
//  Created by iStones on 2018/9/6.
//  Copyright © 2018年 iStones. All rights reserved.
//

#import "OSUnfairLockDemo.h"
#import <os/lock.h>

@interface OSUnfairLockDemo ()
@property (nonatomic, assign) os_unfair_lock moneyLock;
@property (nonatomic, assign) os_unfair_lock ticketLock;
@end

@implementation OSUnfairLockDemo

#pragma mark - init
- (instancetype)init {
    if (self = [super init]) {
        self.moneyLock = OS_UNFAIR_LOCK_INIT;
        self.ticketLock = OS_UNFAIR_LOCK_INIT;
    }
    return self;
}

#pragma mark - override
- (void)__saveMoney {
    os_unfair_lock_lock(&_moneyLock);
    
    [super __saveMoney];
    
    os_unfair_lock_unlock(&_moneyLock);
}

- (void)__drawMoney {
    os_unfair_lock_lock(&_moneyLock);
    
    [super __drawMoney];
    
    os_unfair_lock_unlock(&_moneyLock);
}

- (void)__saleTicket {

    os_unfair_lock_lock(&_ticketLock);
    
    [super __saleTicket];
    
    // 验证当有一条线程进来加锁之后，第二条线程进来等待状态（忙等还是休眠）
    /**
     os_unfair_lock_lock -> _os_unfair_lock_lock_slow -> __ulock_wait，进入之后，发现断点过着过着、到syscall时直接过去了，直接休眠了，这也说明os_unfair_lock_lock线程等待时并非忙等，而是休眠了
     */
    
    os_unfair_lock_unlock(&_ticketLock);
}

@end
