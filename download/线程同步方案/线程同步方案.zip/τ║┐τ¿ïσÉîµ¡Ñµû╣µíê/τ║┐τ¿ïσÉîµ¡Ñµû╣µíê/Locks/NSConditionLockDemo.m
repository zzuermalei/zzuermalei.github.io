//
//  NSConditionLockDemo.m
//  线程同步方案
//
//  Created by iStones on 2018/9/6.
//  Copyright © 2018年 iStones. All rights reserved.
//

#import "NSConditionLockDemo.h"

@interface NSConditionLockDemo ()
@property (nonatomic, strong) NSMutableArray *array;
@property (nonatomic, strong) NSConditionLock *condition;
@end

@implementation NSConditionLockDemo

#pragma mark - init
- (instancetype)init {
    if (self = [super init]) {
        self.array = [NSMutableArray array];
        // 初始化一个条件值 1，直接 init 的话默认条件为 0
        self.condition = [[NSConditionLock alloc] initWithCondition:1];
    }
    return self;
}

#pragma mark - override
- (void)otherTest {
    [[[NSThread alloc] initWithTarget:self selector:@selector(__remove) object:nil] start];
    
    sleep(2);
    
    [[[NSThread alloc] initWithTarget:self selector:@selector(__add) object:nil] start];
}

#pragma mark - private methods
- (void)__add {
    NSLog(@"%s", __func__);
    
    [self.condition lockWhenCondition:1];
    
    [self.array addObject:@"test"];
    NSLog(@"添加了元素");
    
    [self.condition unlockWithCondition:2];
}

- (void)__remove {
    
    NSLog(@"%s", __func__);
    
    [self.condition lockWhenCondition:2];
    
    [self.array removeLastObject];
    NSLog(@"删除了元素");
    
    [self.condition unlock];
}

@end
