//
//  NSConditionDemo.m
//  线程同步方案
//
//  Created by iStones on 2018/9/6.
//  Copyright © 2018年 iStones. All rights reserved.
//

#import "NSConditionDemo.h"

@interface NSConditionDemo ()
@property (nonatomic, strong) NSMutableArray *array;
@property (nonatomic, strong) NSCondition *condition;
@end

@implementation NSConditionDemo

#pragma mark - init
- (instancetype)init {
    if (self = [super init]) {
        self.array = [NSMutableArray array];
        self.condition = [[NSCondition alloc] init];
    }
    return self;
}

#pragma mark - override
- (void)otherTest {
    [[[NSThread alloc] initWithTarget:self selector:@selector(__remove) object:nil] start];
    
    sleep(2);
    
    [[[NSThread alloc] initWithTarget:self selector:@selector(__add) object:nil] start];
}

#pragma mark - private methods
- (void)__add {
    NSLog(@"%s", __func__);
    
    [self.condition lock];
    
    [self.array addObject:@"test"];
    NSLog(@"添加了元素");
   
// 思考这里有什么区别？
#if 0
    // 信号
    [self.condition signal];
    // 广播
//    [self.condition broadcast];
    
    sleep(2);
    
    [self.condition unlock];
#elif 1
    
    sleep(2);
    
    [self.condition unlock];
    
    // 信号
    [self.condition signal];
    // 广播
    //    [self.condition broadcast];
    
#endif
}

- (void)__remove {
    
    NSLog(@"%s", __func__);
    
    [self.condition lock];
    
    if (self.array.count == 0) {
        // 等待
        [self.condition wait];
//        [self.condition waitUntilDate:[NSDate dateWithTimeIntervalSinceNow:2]];
    }
    
    [self.array removeLastObject];
    NSLog(@"删除了元素");
    
    [self.condition unlock];
}

@end
