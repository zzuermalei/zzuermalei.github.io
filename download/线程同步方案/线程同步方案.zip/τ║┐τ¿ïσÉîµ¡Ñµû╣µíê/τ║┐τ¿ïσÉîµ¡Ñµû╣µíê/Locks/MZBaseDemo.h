//
//  MZBaseDemo.h
//  线程同步方案
//
//  Created by iStones on 2018/9/6.
//  Copyright © 2018年 iStones. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MZBaseDemo : NSObject

- (void)moneyTest;
- (void)ticketTest;
- (void)otherTest;

#pragma mark - 供子类使用
- (void)__saveMoney;
- (void)__drawMoney;
- (void)__saleTicket;

@end
