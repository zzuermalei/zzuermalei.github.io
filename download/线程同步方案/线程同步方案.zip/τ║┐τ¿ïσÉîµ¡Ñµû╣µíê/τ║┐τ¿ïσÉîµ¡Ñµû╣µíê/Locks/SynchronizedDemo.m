//
//  SynchronizedDemo.m
//  线程同步方案
//
//  Created by iStones on 2018/9/7.
//  Copyright © 2018年 iStones. All rights reserved.
//

#import "SynchronizedDemo.h"

@implementation SynchronizedDemo

// 也可以用类对象，可以保证不管是哪一个对象，都共用一把锁
- (void)__saveMoney {
    @synchronized(self) {   // objc_sync_enter
        [super __saveMoney];
    }                       // objc_sync_exit
}

- (void)__drawMoney {
    @synchronized(self) {
        [super __drawMoney];
    }
}

- (void)__saleTicket {
    @synchronized(self) {
        [super __saleTicket];
    }
}

- (void)otherTest {
    @synchronized(self) {
        NSLog(@"验证 @synchronized 互斥锁");
        [self otherTest];
    }
}

@end
