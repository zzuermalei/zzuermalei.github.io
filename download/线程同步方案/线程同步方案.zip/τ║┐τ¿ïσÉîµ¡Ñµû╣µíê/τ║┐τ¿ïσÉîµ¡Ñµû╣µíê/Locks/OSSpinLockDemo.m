//
//  OSSpinLockDemo.m
//  线程同步方案
//
//  Created by iStones on 2018/9/6.
//  Copyright © 2018年 iStones. All rights reserved.
//

#import "OSSpinLockDemo.h"
#import <libkern/OSAtomic.h>

@interface OSSpinLockDemo ()
// c语言类型，用 assign 修饰
@property (nonatomic, assign) OSSpinLock moneyLock;
@property (nonatomic, assign) OSSpinLock ticketLock;
@end

@implementation OSSpinLockDemo

#pragma mark - init
- (instancetype)init {
    if (self = [super init]) {
        self.moneyLock = OS_SPINLOCK_INIT;
        self.ticketLock = OS_SPINLOCK_INIT;
    }
    return self;
}

#pragma mark - override
- (void)__saveMoney {
    OSSpinLockLock(&_moneyLock);

    [super __saveMoney];
    
    OSSpinLockUnlock(&_moneyLock);
}

- (void)__drawMoney {
    OSSpinLockLock(&_moneyLock);
    
    [super __drawMoney];
    
    OSSpinLockUnlock(&_moneyLock);
}

- (void)__saleTicket {
#if 1
    OSSpinLockLock(&_ticketLock);
    
    [super __saleTicket];
    
    // 验证当有一条线程进来加锁之后，第二条线程进来等待状态（忙等还是休眠）
    // Xcode -> Debug Workflow -> Always show Disassembly
    /**
     我们通过 si 指令，一行一行走，进入 OSSpinLockLock 函数，继续，进入 _OSSpinLockLockSlow 函数，这个时候要注意了：会一直在一块儿内存地址代码之间重复执行，这种就是典型的while循环，自旋锁，只有锁被放开之后才会往下继续执行
     */
//    sleep(500);
    
    OSSpinLockUnlock(&_ticketLock);
#elif 0
    // 只有一个地方需要用到，也可以使用静态变量；
    // 为什么可以用 static 初始化，static 需要在编译时就确定是什么值。 点进去发现 OS_SPINLOCK_INIT 其实就是个 0
    static OSSpinLock lock = OS_SPINLOCK_INIT;
    
    OSSpinLockLock(&lock);
    
    [super __saleTicket];
    
    OSSpinLockUnlock(&lock);
#endif
}

@end
