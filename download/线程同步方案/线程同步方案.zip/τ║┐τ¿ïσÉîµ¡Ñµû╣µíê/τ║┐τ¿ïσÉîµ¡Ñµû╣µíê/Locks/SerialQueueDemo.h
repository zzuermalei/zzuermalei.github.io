//
//  SerialQueueDemo.h
//  线程同步方案
//
//  Created by iStones on 2018/9/7.
//  Copyright © 2018年 iStones. All rights reserved.
//

#import "MZBaseDemo.h"

@interface SerialQueueDemo : MZBaseDemo

@end
