//
//  MZPerson.h
//  线程同步方案
//
//  Created by iStones on 2018/9/7.
//  Copyright © 2018年 iStones. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MZPerson : NSObject

@property (nonatomic, assign) int age;
@property (atomic, copy) NSString *name;

@end

/**
 nonatomic 和 atomic
 atom：原子 
 atomic：原子性
 
 给属性加上atomic属性修饰，可以保证属性的setter和getter都是原子性操作，也就是保证setter和getter内部都是线程同步的，相当于下面：
 
 - (void)setName:(NSString *)name {
     // 加锁
     _name = name;
     // 加锁
 }
 
 - (NSString *)name {
     // 加锁
     // 取值
     // 解锁
     // 返回
     return _name;
 }
 */



