//
//  ViewController.m
//  线程同步方案
//
//  Created by iStones on 2018/9/5.
//  Copyright © 2018年 iStones. All rights reserved.
//

#import "ViewController.h"
#import "MZBaseDemo.h"
#import "OSSpinLockDemo.h"
#import "OSUnfairLockDemo.h"
#import "PthreadMutexDemo.h"
#import "PthreadMutexCondDemo.h"
#import "NSLockDemo.h"
#import "NSConditionDemo.h"
#import "NSConditionLockDemo.h"
#import "SerialQueueDemo.h"
#import "SemaphoreDemo.h"
#import "SynchronizedDemo.h"

#import "ReadWriteTestDemo1.h"
#import "ReadWriteTestDemo2.h"
#import "ReadWriteTestDemo3.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
#if 0
    MZBaseDemo *demo = [[SynchronizedDemo alloc] init];
    [demo moneyTest];
    [demo ticketTest];
    
//    [demo otherTest];
#elif 1
//    ReadWriteTestDemo1 *rwTest = [[ReadWriteTestDemo1 alloc] init];
//    ReadWriteTestDemo2 *rwTest = [[ReadWriteTestDemo2 alloc] init];
    ReadWriteTestDemo3 *rwTest = [[ReadWriteTestDemo3 alloc] init];
    [rwTest test];
#endif
}

#pragma mark - event response
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    
}

@end
