//
//  ReadWriteTestDemo1.m
//  线程同步方案
//
//  Created by iStones on 2018/9/8.
//  Copyright © 2018年 iStones. All rights reserved.
//

#import "ReadWriteTestDemo1.h"

@interface ReadWriteTestDemo1 ()
@property (nonatomic, strong) dispatch_semaphore_t semphore;
@end

@implementation ReadWriteTestDemo1

- (instancetype)init {
    if (self = [super init]) {
        self.semphore = dispatch_semaphore_create(1);
    }
    return self;
}

#pragma mark - public methods
- (void)test {
    for (NSInteger i = 0; i < 10; i++) {
        [[[NSThread alloc] initWithTarget:self selector:@selector(read) object:nil] start];
        [[[NSThread alloc] initWithTarget:self selector:@selector(write) object:nil] start];
    }
}

#pragma mark - private methods
/**
 如果读也加上 semaphore 的话，确实可以保证读写都安全，同时只能读或者写，但是没必要。iOS中读写方案一般设计多读单写，读不涉及资源抢占，可以同时进行。
 
 但是，这样依然存在问题，虽然可以多读单写。但是写入加锁了，读却没有加锁，读的同时依然可以写，这个依然不可控，依然不安全，不能保证读的同时没有线程在进行写的操作。
 */
- (void)read {
//    dispatch_semaphore_wait(self.semphore, DISPATCH_TIME_FOREVER);
    
    NSLog(@"%s", __func__);
    
//    dispatch_semaphore_signal(self.semphore);
}

- (void)write {
    dispatch_semaphore_wait(self.semphore, DISPATCH_TIME_FOREVER);
    
    NSLog(@"%s", __func__);
    
    dispatch_semaphore_signal(self.semphore);
}

@end
