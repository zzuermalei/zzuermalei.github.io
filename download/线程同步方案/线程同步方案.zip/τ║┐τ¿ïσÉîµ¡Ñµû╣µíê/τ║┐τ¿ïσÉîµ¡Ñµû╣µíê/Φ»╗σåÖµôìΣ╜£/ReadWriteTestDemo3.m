//
//  ReadWriteTestDemo3.m
//  线程同步方案
//
//  Created by iStones on 2018/9/8.
//  Copyright © 2018年 iStones. All rights reserved.
//

#import "ReadWriteTestDemo3.h"

@interface ReadWriteTestDemo3 ()
@property (nonatomic, strong) dispatch_queue_t rwQueue;
@end

@implementation ReadWriteTestDemo3

- (instancetype)init {
    if (self = [super init]) {
        self.rwQueue = dispatch_queue_create("top.istones.rwQueue", DISPATCH_QUEUE_CONCURRENT);
    }
    return self;
}

#pragma mark - public methods
- (void)test {
    for (NSInteger i = 0; i < 10; i++) {
        [self read];
        [self read];
        
        [self write];
        [self write];
        
        [self read];
    }
}

#pragma mark - private methods
- (void)read {
    dispatch_async(self.rwQueue, ^{
        NSLog(@"%s", __func__);
        sleep(1);
    });
}

- (void)write {
    dispatch_barrier_async(self.rwQueue, ^{
        NSLog(@"%s", __func__);
        sleep(1);
    });
}

@end
