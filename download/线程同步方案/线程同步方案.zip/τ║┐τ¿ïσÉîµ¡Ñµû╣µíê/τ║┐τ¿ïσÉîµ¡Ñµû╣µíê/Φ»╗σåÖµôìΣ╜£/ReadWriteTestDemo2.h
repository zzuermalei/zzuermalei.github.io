//
//  ReadWriteTestDemo2.h
//  线程同步方案
//
//  Created by iStones on 2018/9/8.
//  Copyright © 2018年 iStones. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ReadWriteTestDemo2 : NSObject

- (void)test;

@end
