//
//  ReadWriteTestDemo2.m
//  线程同步方案
//
//  Created by iStones on 2018/9/8.
//  Copyright © 2018年 iStones. All rights reserved.
//

#import "ReadWriteTestDemo2.h"
#import <pthread.h>

@interface ReadWriteTestDemo2 ()
@property (nonatomic, assign) pthread_rwlock_t lock;
@end

@implementation ReadWriteTestDemo2

- (instancetype)init {
    if (self = [super init]) {
        pthread_rwlock_init(&_lock, NULL);
    }
    return self;
}

#pragma mark - public methods
- (void)test {
    for (NSInteger i = 0; i < 10; i++) {
        dispatch_async(dispatch_get_global_queue(0, 0), ^{
            [self read];
        });
        
        dispatch_async(dispatch_get_global_queue(0, 0), ^{
            [self write];
        });
    }
}

#pragma mark - private methods
- (void)read {
    pthread_rwlock_rdlock(&_lock);
    
    NSLog(@"%s", __func__);
    sleep(1);
    
    pthread_rwlock_unlock(&_lock);
}

- (void)write {

    pthread_rwlock_wrlock(&_lock);
    
    NSLog(@"%s", __func__);
    
    sleep(1);
    
    pthread_rwlock_unlock(&_lock);
}

- (void)dealloc {
    pthread_rwlock_destroy(&_lock);
}

@end
