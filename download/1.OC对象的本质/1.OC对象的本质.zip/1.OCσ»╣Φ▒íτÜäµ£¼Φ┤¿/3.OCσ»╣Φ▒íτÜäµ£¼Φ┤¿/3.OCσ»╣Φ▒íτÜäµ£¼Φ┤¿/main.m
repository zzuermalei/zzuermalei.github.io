//
//  main.m
//  3.OC对象的本质
//
//  Created by iStones on 2018/8/27.
//  Copyright © 2018年 iStones. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <objc/runtime.h>
#import <malloc/malloc.h>

struct NSObject_IMPL {
    Class isa;
};

struct Person_IMPL {
    struct NSObject_IMPL NSObject_IVARS;    // 8
    int _age;   // 4
};
// Person_IMPL: 占用 12 个字节? 错，其实占用 16 个字节, 内存对齐：结构体的大小比必须是最大成员大小的倍数


struct Student_IMPL {
    struct Person_IMPL Person_IVARS;    // 16
    int _no;    // 4
};
/**
 Student_IMPL: 16 + 4 = 20; 上面讲到内存对齐规定结构体的大小比必须是最大成员大小的倍数，那么实际占用 16 * 2 = 32 个字节么？错！结果为 16 * 1 = 16 个字节。
为什么呢？因为 Person_IMPL 虽然分配16个字节，但是实际变量只占用了 12 个字节，还有 4 个字节空出来了，我们伟大的 iOS 系统会这么傻，白白浪费这 4 个字节的空间么，
 当然不会，所以，int _no；其实被放到了 Person_IMPL 空余的 4 个字节空间当中。
*/

@interface Person: NSObject {
    @public
    int _age;
}
@end

@implementation Person
@end

@interface Student: Person {
    @public
    int _no;
}
@end

@implementation Student
@end

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        
        Student *stu = [[Student alloc] init];
        stu->_no = 5;
        // 输出为 >> 16 16
        NSLog(@"student:%zd, %zd", class_getInstanceSize([Student class]), malloc_size((__bridge const void*)stu));
        
        Person *per = [[Person alloc] init];
        per->_age = 4;
        // 输出为 >> 16 16
        NSLog(@"person:%zd, %zd", class_getInstanceSize([Person class]), malloc_size((__bridge const void*)per));
    }
    return 0;
}
