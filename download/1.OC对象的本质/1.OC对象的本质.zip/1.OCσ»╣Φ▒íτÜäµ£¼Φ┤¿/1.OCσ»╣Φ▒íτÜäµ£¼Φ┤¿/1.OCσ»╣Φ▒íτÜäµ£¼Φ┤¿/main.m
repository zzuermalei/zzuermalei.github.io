//
//  main.m
//  1.OC对象的本质
//
//  Created by iStones on 2018/8/22.
//  Copyright © 2018年 iStones. All rights reserved.
//
//  将 main.m 输出为 main.cpp
//  xcrun  -sdk  iphoneos  clang  -arch  arm64  -rewrite-objc main.m  -o main.cpp
//  如果需要链接其他框架，使用-framework参数。比如-framework UIKit

#import <Foundation/Foundation.h>
#import <objc/runtime.h>
#import <malloc/malloc.h>

// isa 本质就是一个指向 objc_class 结构体的指针
//typedef struct objc_class *Class;

// NSObject Implementation (NSObject 底层实现)
struct NSObject_IMPL {
    // isa 既然是一个指针，64位占8个字节，32位占4个字节，既然这样，我们可以认为一个 NSObject 对象就占8个字节么。 错，不能这样认为，后面为带来详解。
    Class isa;
};

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        
        NSObject *obj = [[NSObject alloc] init];
        
        // 获得 NSObject 实例对象的成员变量所占用的大小 >> 8
        NSLog(@"%zd", class_getInstanceSize([NSObject class])); // 输出为8
        
        // 获得 obj 指针所指向内存的大小 >> 16
        NSLog(@"%zd", malloc_size((__bridge const void *)(obj))); // 输出为 16
        
        // 什么平台的代码
        // 不同平台支持的代码不一样
        // Windows、mac、iOS
        // 模拟器(i386)、32bit(armv7)、64bit(arm64)
        
    }
    return 0;
}
