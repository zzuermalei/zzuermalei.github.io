//
//  main.m
//  2.OC对象的本质
//
//  Created by iStones on 2018/8/27.
//  Copyright © 2018年 iStones. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <objc/runtime.h>
#import <malloc/malloc.h>

struct NSObject_IMPL {
    Class isa;
};

struct Student_IMPL {
    // OC 中如果继承的话，这里相当于把父类结构体里面的变量直接 copy 过来
    // 相当于
    // Class isa
    struct NSObject_IMPL NSObject_IVARS;
    int _no;
    int _age;
};

@interface Student : NSObject {
    @public
    int _no;
    int _age;
}
@end

@implementation Student
@end

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        
        Student *stu = [[Student alloc] init];
        stu->_no = 4;
        stu->_age = 5;
        
        // 输出为 >> 16
        NSLog(@"%zd", class_getInstanceSize([Student class]));
        // 输出为 >> 16
        NSLog(@"%zd", malloc_size((__bridge const void*)stu));
        
        struct Student_IMPL *stu2 = (__bridge struct Student_IMPL *)stu;
        NSLog(@"%d, %d", stu2->_no, stu2->_age);
        
    }
    return 0;
}
